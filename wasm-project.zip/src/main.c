#define WASM_EXPORT __attribute__((visibility("default")))

WASM_EXPORT
int answerWASM() {
  return 42;
}
